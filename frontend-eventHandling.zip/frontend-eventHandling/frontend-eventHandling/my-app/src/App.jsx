import { useState } from 'react';
import React from 'react';
import './App.css';



function EventHandlingComponent() {

  const [displayText1, setDisplayText1] = useState(null);
  const [displayText2, setDisplayText2] = useState(null);
  const inputRef = useState(null);
  const [inputCss, setCss] = useState(null);

  // onClick Button
  const handleClick = () => {
    setDisplayText1('onClick Button:');
    setDisplayText2('Button ditekan!');
  };
  
  // onChange inputBox
  const handleChange = (event) => {
    setDisplayText1('onChange inputBox:');
    setDisplayText2(event.target.value);
  };

  // onChange comboBox
  const handleChange2 = (event) => {
    setDisplayText1('onChange comboBox:');
    setDisplayText2(event.target.value);
  };

  // onChange radioButton
  const handleChange3 = (event) => {
    setDisplayText1('onChange radioButton:');
    setDisplayText2(event.target.value);
  };

  // onSubmit
  const handleSubmit = (event) => {
    event.preventDefault();
    setDisplayText1('onSubmit Form:');
    setDisplayText2(inputRef.current.value);
    // tambahkan logika untuk menangani submit form di sini
  };

  // onFocus
  const handleFocus = (event) => {
    setCss('inputCss');
    setDisplayText1('onFocus inputBox:');
    setDisplayText2('inputBox change color red');
  };

  return (
    <div className="container">
      <div className="event-handling">
        <h3>EVENT HANDLING</h3>
        <div className="event-section">
          <strong>onClick</strong>
          <br />
          <button id="clickButton" onClick={handleClick}>
            BUTTON
          </button>
        </div>
        <div className="event-section">
          <strong>onChange</strong>
          <br />
          <label>
            inputBox :
            <input type="text" id="inputBox" onChange={handleChange} />
          </label>
          <br />
          <label>
            comboBox :
            <select id="comboBox" onChange={handleChange2}>
              <option value="CB_PILIHAN 1">CB_PILIHAN 1</option>
              <option value="CB_PILIHAN 2">CB_PILIHAN 2</option>
              <option value="CB_PILIHAN 3">CB_PILIHAN 3</option>
            </select>
          </label>
          <br />
          <label>
            radioButton :
            <br />
            <input
              type="radio"
              name="radioButton"
              value="RB_PILIHAN 1"
              onChange={handleChange3}
            />{' '}
            RB_PILIHAN 1
            <br />
            <input
              type="radio"
              name="radioButton"
              value="RB_PILIHAN 2"
              onChange={handleChange3}
            />{' '}
            RB_PILIHAN 2
            <br />
            <input
              type="radio"
              name="radioButton"
              value="RB_PILIHAN 3"
              onChange={handleChange3}
            />{' '}
            RB_PILIHAN 3
          </label>
        </div>

        <div className="event-section">
          <strong>onSubmit</strong>
          <br />
          <form id="submitForm" onSubmit={handleSubmit}>
            <label>
              Name :
              <input type="text" id="nameInput" ref={inputRef} />
            </label>
            <button type="submit">Submit</button>
          </form>
        </div>

        <div className="event-section">
          <strong>onFocus</strong>
          <br />
          <label>
            inputBox :
            <input type="text" id="focusInput" className={inputCss} onFocus={handleFocus} />
          </label>
        </div>
      </div>
      <div className="results">
        <h3>RESULTS</h3>
        <div className="mid-results">
          <p>{displayText1}</p>
          <h1>{displayText2}</h1>
        </div>
      </div>
    </div>
  );
}

export default EventHandlingComponent;

